<?php
// Get the form data
$username = $_POST['username'];
$email_id = $_POST['email_id'];
$mob_no = $_POST['mob_no'];
$emp_id = $_POST['emp_id'];

// Save the form data to a file
$file = '/var/www/html/uploads/data.txt';
#file = '/home/data.csv';
#$file = '/mnt/data.csv';
$handle = fopen($file, 'a');
fwrite($handle, "$username\n");
fwrite($handle, "$email_id\n");
fwrite($handle, "$mob_no\n");
fwrite($handle, "$emp_id\n");

#$Emp_ID,$Mobile_No,$Email\n");
fclose($handle);


// Set the thank you message
$thankYouMessage = "Thank you for submitting your information!";

// Redirect the user to the success page
#header("Location: success.html?thankYouMessage=$thankYouMessage");
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Form Submission</title>
<style>
body
{
display: flex;
justify-content: center;
align-items: center;
height : 100vh;
margin:0;
}

.message {
font-size: 24px;
text-align:center;
}
</style>
</head>
<body>
<div class="message">

<p><?php echo $thankYouMessage; ?><p>
</div>
</body>
</html>


