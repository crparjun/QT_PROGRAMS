#include<QApplication>
#include<QWidget>
#include<QMoveEvent>
#include<QMainWindow>


class simple : public QWidget
{
	public:
		simple(QWidget *parent = 0);
	protected:
		void move(QMoveEvent *e);
};
simple::simple(QWidget *parent)
	:QWidget(parent)
{
}
void simple::move(QMoveEvent *e)
{
	int x = e->pos().x();
	int y = e->pos().y();

	QString text = QString::number(x)+","+QString::number(y);
        setWindowTitle(text);
}

int main(int argc,char *argv[])
{
	QApplication app(argc,argv);
	
	simple window;

	window.resize(400,200);

	//window.setWindowTitle("move");
	
	window.show();

	return app.exec();
}

