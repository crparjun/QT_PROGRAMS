#include<QApplication>
#include<QWidget>
#include<QKeyEvent>


class simple : public QWidget
{
	public :
		simple(QWidget *parent = nullptr);
	protected :
		void key(QKeyEvent *e);
};
simple::simple(QWidget *parent)
	:QWidget(parent)
{
}
void simple::key(QKeyEvent *event)
{
	if(event->key() == Qt::Key_Escape)
	{
		qApp->quit();
	}
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple window;

	window.resize(400,200);

	window.setWindowTitle("KEY PRESS ");

	window.show();

	return app.exec();
}
