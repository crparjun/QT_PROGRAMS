#include<QApplication>
#include<QWidget>
#include<QPushButton>

class simple : public QWidget
{
	public : 
		simple(QWidget *parent = nullptr);
};
simple::simple(QWidget *parent)
	:QWidget(parent)
{


	auto *b1 = new QPushButton("submit",this);
	b1->setGeometry(150,150,100,100);
	b1->setStyleSheet("background-color:grey;");


	connect(b1,&QPushButton::clicked,qApp,&QApplication::quit);

}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple window;

	window.resize(400,400);

	window.setWindowTitle("QT CLICKABLE MENU");

	window.show();

	return app.exec();
}
