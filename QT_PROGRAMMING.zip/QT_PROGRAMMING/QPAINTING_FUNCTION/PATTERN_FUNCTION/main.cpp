#include<QApplication>
#include<QWidget>
#include<QPainter>
#include<QDesktopWidget>

class simple : public QWidget
{
	public:
		simple(QWidget *parent = nullptr);
	protected:
		void paint(QPaintEvent *e);
	private:
		void painting(QPainter *painter);
};

simple::simple(QWidget *parent)
	:QWidget(parent)
{}

void  simple::paint(QPaintEvent *e)
{
	Q_UNUSED(e);
	QPainter painter(this);
	painter.setPen(Qt::NoPen);
	painting(&painter);
	painter.end();
}
void simple::painting(QPainter *painter)
{
	painter->setBrush(Qt::HorPattern);
	painter->drawRect(10,15,90,60);

	painter->setBrush(Qt::VerPattern);
	painter->drawRect(130, 15, 90, 60);

	painter->setBrush(Qt::CrossPattern);
	painter->drawRect(250, 15, 90, 60);

	painter->setBrush(Qt::Dense7Pattern);
	painter->drawRect(10, 105, 90, 60);

	painter->setBrush(Qt::Dense6Pattern);
	painter->drawRect(130, 105, 90, 60);

	painter->setBrush(Qt::Dense5Pattern);
	painter->drawRect(250, 105, 90, 60);

	painter->setBrush(Qt::BDiagPattern);
	painter->drawRect(10, 195, 90, 60);

	painter->setBrush(Qt::FDiagPattern);
	painter->drawRect(130, 195, 90, 60);

	painter->setBrush(Qt::DiagCrossPattern);
	painter->drawRect(250, 195, 90, 60);
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple w;

	w.resize(350,280);

	w.setWindowTitle("PATTERNS STYLE");

	w.show();

	return app.exec();
}

