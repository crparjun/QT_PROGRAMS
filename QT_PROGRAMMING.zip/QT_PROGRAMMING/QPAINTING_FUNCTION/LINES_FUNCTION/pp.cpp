#include <QApplication>
#include <QWidget>
#include <QPainter>

class Simple : public QWidget
{
	public:
		    Simple(QWidget *parent = nullptr);

	protected:
		        void paintEvent(QPaintEvent *e);
};

Simple::Simple(QWidget *parent) : QWidget(parent) {}

void Simple::paintEvent(QPaintEvent *e)
{
	    Q_UNUSED(e);
	    QPainter painter(this);

            QPen pen(Qt::black, 2, Qt::SolidLine);
	    painter.setPen(pen);
	    painter.drawLine(20, 40, 250, 40);
	    
	    pen.setStyle(Qt::DashLine);
	    painter.setPen(pen);
	    painter.drawLine(20, 80, 250, 80);

	    pen.setStyle(Qt::DashDotLine);
	    painter.setPen(pen);
	    painter.drawLine(20, 120, 250, 120);

	    pen.setStyle(Qt::DotLine);
	    painter.setPen(pen);
	    painter.drawLine(20, 160, 250, 160);

	    pen.setStyle(Qt::DashDotDotLine);
	    painter.setPen(pen);
	    painter.drawLine(20, 200, 250, 200);

	   QWidget::paintEvent(e);

}
int main(int argc, char *argv[])
{
	QApplication app(argc, argv);
	Simple w;
	w.resize(270,270);
	w.setWindowTitle("QLINES EDIT");
	w.show();
	return app.exec();
}
