#include<QApplication>
#include<QWidget>
#include<QPainter>

class simple : public QWidget
{
	public :
		simple(QWidget *parent = nullptr);
		
	protected:
		void paintEvent(QPaintEvent *e);
		
	private:
		void doPainting();
};
simple::simple(QWidget *parent)
	:QWidget(parent)
{ }
void simple::paintEvent(QPaintEvent *e)
{
	Q_UNUSED(e);
	doPainting();
}
void simple::doPainting()
{
	QPainter painter(this);
	QLinearGradient grad1(0,20,0,110);

	grad1.setColorAt(0.1,Qt::black);
	grad1.setColorAt(0.5,Qt::yellow);
	grad1.setColorAt(0.9,Qt::black);

	painter.fillRect(20,20,300,90,grad1);


	QLinearGradient grad2(0, 55, 250, 0);
	  grad2.setColorAt(0.2, Qt::black);
	    grad2.setColorAt(0.5, Qt::red);
	      grad2.setColorAt(0.8, Qt::black);
	        painter.fillRect(20, 140, 300, 100, grad2);
}
int main(int argc, char *argv[]) {
	    
	  QApplication app(argc, argv);  
	      
	    simple window;

	      window.resize(500, 300);  
	        window.setWindowTitle("Linear gradients");
		  window.show();

		    return app.exec();
}
