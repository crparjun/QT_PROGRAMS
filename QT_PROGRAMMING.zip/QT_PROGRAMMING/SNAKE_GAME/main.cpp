#include<QApplication>
#include<QWidget>
#include<QKeyEvent>
#include<QTime>
#include<QPainter>

class simple : public QWidget
{
	public :
		simple(QWidget *parent = nullptr);
	protected:
		void paintEvent(QPaintEvent *);
		void timerEvent(QTimerEvent *);
		void keyPressEvent(QKeyEvent *);
	private:
		  QImage dot;
		  QImage head;
	          QImage apple;

		  static const int B_WIDTH = 800;
		  static const int B_HEIGHT = 500;
	          static const int DOT_SIZE = 10;
	          static const int ALL_DOTS = 900;
	          static const int RAND_POS = 29;
		  static const int DELAY = 140;

		  int timerId;
		  int dots;
	          int apple_x;
	          int apple_y;

		  int x[ALL_DOTS];
		  int y[ALL_DOTS];

		  bool leftDirection;
		  bool rightDirection;
	          bool upDirection;
	          bool downDirection;
		  bool inGame;

		  void loadImages();
		  void initGame();
	          void locateApple();
	          void checkApple();
	          void checkCollision();
		  void move();
		  void doDrawing();
	          void gameOver(QPainter &);

};

simple::simple(QWidget *parent)
	:QWidget(parent)
{
	setStyleSheet("background-color:black;");
	leftDirection = false;
	rightDirection = true;
        upDirection = false;
        downDirection = false;

	setFixedSize(B_WIDTH, B_HEIGHT);
	loadImages();
	initGame();
	inGame = true;
}
void simple::loadImages() {

	dot.load("body.png");
	head.load("snake.png");
        apple.load("images.jpg");
}
void simple::initGame() {

        dots = 3;
	for (int z = 0; z < dots; z++) {
	x[z] = 50 - z * 10;
	y[z] = 50;
	}
	locateApple();
	timerId = startTimer(DELAY);
}
void simple::paintEvent(QPaintEvent *e) {
	Q_UNUSED(e);
	doDrawing();
}
void simple::doDrawing() {
	QPainter qp(this);
	if (inGame) {
		qp.drawImage(apple_x, apple_y, apple);
		for (int z = 0; z < dots; z++) {
			if (z == 0) {
				qp.drawImage(x[z], y[z], head);
			} else {
				qp.drawImage(x[z], y[z], dot);
		}
		}

		} else {

		gameOver(qp);
		}
}

void simple::gameOver(QPainter &qp) {
	QString message = "Game over";
	QFont font("Courier", 15, QFont::DemiBold);
	QFontMetrics fm(font);
	int textWidth = fm.horizontalAdvance(message);
	qp.setFont(font);
	int h = height();
	int w = width();
	qp.translate(QPoint(w/2, h/2));
	qp.drawText(-textWidth/2, 0, message);
}
void simple::checkApple() {
	if ((x[0] == apple_x) && (y[0] == apple_y)) {
		dots++;
		locateApple();
	}
}
void simple::move() {
	for (int z = dots; z > 0; z--) {
		x[z] = x[(z - 1)];
		y[z] = y[(z - 1)];
	}
	if (leftDirection) {
        x[0] -= DOT_SIZE;
	}
	if (rightDirection) {
		x[0] += DOT_SIZE;
	}
	if (upDirection) {
		y[0] -= DOT_SIZE;
	}
	if (downDirection) {
		y[0] += DOT_SIZE;
	}
}
void simple::checkCollision() {
	for (int z = dots; z > 0; z--) {
		if ((z > 4) && (x[0] == x[z]) && (y[0] == y[z])) {
			inGame = false;
		}
	}
	if (y[0] >= B_HEIGHT) {
		inGame = false;
	}
       	if (y[0] < 0) {
		inGame = false;
	}
	if (x[0] >= B_WIDTH) {
		inGame = false;
	}
	if (x[0] < 0) {
		inGame = false;
	}
	if(!inGame) {
		killTimer(timerId);
	}
}

void simple::locateApple() {

	    QTime time = QTime::currentTime();
	        qsrand((uint) time.msec());

		    int r = qrand() % RAND_POS;
		        apple_x = (r * DOT_SIZE);

			    r = qrand() % RAND_POS;
			        apple_y = (r * DOT_SIZE);
}

void simple::timerEvent(QTimerEvent *e) {

	    Q_UNUSED(e);

	        if (inGame) {

			        checkApple();
				        checkCollision();
					        move();
						    }

		    repaint();
}

void simple::keyPressEvent(QKeyEvent *e) {

	    int key = e->key();

	        if ((key == Qt::Key_Left) && (!rightDirection)) {
			        leftDirection = true;
				        upDirection = false;
					        downDirection = false;
						    }

		    if ((key == Qt::Key_Right) && (!leftDirection)) {
			            rightDirection = true;
				            upDirection = false;
					            downDirection = false;
						        }

		        if ((key == Qt::Key_Up) && (!downDirection)) {
				        upDirection = true;
					        rightDirection = false;
						        leftDirection = false;
							    }

			    if ((key == Qt::Key_Down) && (!upDirection)) {
				            downDirection = true;
					            rightDirection = false;
						            leftDirection = false;
							        }

			        QWidget::keyPressEvent(e);
}


int main(int argc,char *argv[])
{
	QApplication app(argc, argv);

	  simple window;

	  window.resize(800,800);

	    window.setWindowTitle("Snake");
	      window.show();

	        return app.exec();
}


