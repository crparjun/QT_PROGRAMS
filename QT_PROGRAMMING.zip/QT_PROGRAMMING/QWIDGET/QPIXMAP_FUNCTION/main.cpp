#include<QApplication>
#include<QWidget>
#include<QPixmap>
#include<QLabel>
#include<QHBoxLayout>

class simple : public QWidget
{
	public:
		simple(QWidget *parent = nullptr);
};
simple::simple(QWidget *parent)
	:QWidget(parent)
{

	auto *h = new QHBoxLayout(this);

	QPixmap p("p.png");
	
	auto *l = new QLabel(this);
	l->setPixmap(p);

	h->addWidget(l,1,Qt::AlignTop);

}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple w;

	w.resize(400,200);

	w.setWindowTitle("QPIXMAP FUNCTION");

	w.show();

	return app.exec();

}
