#include<QApplication>
#include<QWidget>
#include<QTableWidget>
#include<QHBoxLayout>


class simple : public QWidget
{
	public:
		simple(QWidget *parent = nullptr);
};
simple::simple(QWidget *parent)
	:QWidget(parent)
{
	auto *h = new QHBoxLayout(this);

	auto *table = new QTableWidget(25,25,this);
	
	h->addWidget(table);
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple w;

	w.resize(500,500);

	w.setWindowTitle("QTABLEWIDGET-FUNCTION");
	
	w.show();

	return app.exec();
}
