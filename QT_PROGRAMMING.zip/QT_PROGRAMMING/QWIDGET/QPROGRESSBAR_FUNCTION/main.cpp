#include<QApplication>
#include<QWidget>
#include<QProgressBar>
#include<QPushButton>
#include<QTimer>
#include<QGridLayout>

class simple : public QWidget
{
	public:
		simple(QWidget *parent = nullptr);
		private slots:
			void update();
		        void start();
			void stop();
		private :
			QProgressBar *b;
			QPushButton *p1;
			QPushButton *p2;
			QTimer *t;
			int progress;
			static const int DELAY = 200;
			static const int MAX = 100;
};
simple::simple(QWidget *parent)
	:QWidget(parent)
{

	progress = 0;
	t = new QTimer(this);
	connect(t,&QTimer::timeout,this,&simple::update);

	auto *grid = new QGridLayout(this);
	grid->setColumnStretch(2,1);

	b = new QProgressBar();
	b->setStyleSheet("background-color:grey;");
	grid->addWidget(b,0,0,1,3);

	p1 = new QPushButton("start",this);
	p1->setStyleSheet("background-color:yellow;");

	connect(p1,&QPushButton::clicked,this,&simple::start);
	grid->addWidget(p1,1,0,1,1);

	p2 = new QPushButton("stop",this);
        p2->setStyleSheet("background-color:yellow;");
	connect(p2,&QPushButton::clicked,this,&simple::stop);
	grid->addWidget(p2,1,1);
}

void simple::start()
{
	if(progress >= MAX)
	{
		progress = 0;
		b->setValue(0);
	}
	if(!t->isActive())
	{
		p1->setEnabled(false);
		p2->setEnabled(true);
		t->start(DELAY);
	}
}
void simple::stop()
{
	if(t->isActive())
	{
		p1->setEnabled(true);
		p2->setEnabled(false);
		t->stop();
	}
}
void simple::update()
{
	progress++;
	if(progress <= MAX)
	{
		b->setValue(progress);
	}
	else
	{
		t->stop();
		p1->setEnabled(true);
		p2->setEnabled(false);
	}
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple w;

	w.resize(400,200);

	w.setStyleSheet("background-color:lightblue");

	w.setWindowTitle("QPROGRESSBAR - FUNCTION");

	w.show();

	return app.exec();

}


