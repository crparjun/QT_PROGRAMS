#include<QApplication>
#include<QWidget>
#include<QHBoxLayout>
#include<QVBoxLayout>
#include<QPushButton>
#include<QLineEdit>
#include<QListWidget>
#include<QInputDialog>

class simple : public QWidget
{
	public:
		simple(QWidget *parent = nullptr);
		private slots:
			void add();
		        void rename();
			void remove();
			void removeall();
	private:
			QListWidget *lw;
			QPushButton *p1;
			QPushButton *p2;
			QPushButton *p3;
			QPushButton *p4;
};

simple::simple(QWidget *parent)
	:QWidget(parent)
{
	auto *v = new QVBoxLayout(this);
	v->setSpacing(10);

	auto *h = new QHBoxLayout(this);

	lw = new QListWidget(this);

	lw->addItem("apples");
	lw->addItem("Mango");
	lw->addItem("Apples");
	lw->addItem("Banana");
	lw->addItem("Papaya");
	lw->addItem("Graphes");
	lw->addItem("Pomogrant");

	p1 = new QPushButton("ADD",this);
        p2 = new QPushButton("RENAME",this);
        p3 = new QPushButton("REMOVE",this);
        p4 = new QPushButton("REMOVE ALL",this);

        v->setSpacing(3);
        v->addStretch(1);
        v->addWidget(p1);
	v->addWidget(p2); 
        v->addWidget(p3); 
        v->addWidget(p4); 
	v->addStretch(1);

	h->addWidget(lw);
	h->addSpacing(15);
	h->addLayout(v);

	connect(p1,&QPushButton::clicked,this,&simple::add);
	connect(p2,&QPushButton::clicked,this,&simple::rename); 
	connect(p3,&QPushButton::clicked,this,&simple::remove); 
	connect(p4,&QPushButton::clicked,this,&simple::removeall); 

	setLayout(h);
}

void simple::add()
{
	QString c_text = QInputDialog::getText(this,"ITEM","ENTER NEW ITEM");
	QString s_text = c_text.simplified();

	if(!s_text.isEmpty())
	{
		lw->addItem(s_text);
		int r = lw->count()-1;
		lw->setCurrentRow(r);
	}
}
void simple::rename()
{
	QListWidgetItem *cur = lw->currentItem();
	int r = lw->row(cur);
	QString c_text = cur->text();
	QString r_text = QInputDialog::getText(this,"Item","ENTER NEW ITEM",QLineEdit::Normal,c_text);
	QString s_text = r_text.simplified();
	if(!s_text.isEmpty())
	{
		QListWidgetItem *item = lw->takeItem(r);
		delete item;
		lw->insertItem(r,s_text);
		lw->setCurrentRow(r);
	}
}
void simple::remove()
{
	int r = lw->currentRow();
	
	if(r != -1)
	{
		QListWidgetItem *item = lw->takeItem(r);
		delete item;
	}
}
void simple::removeall()
{
	if(lw->count() != 0)
	{
		lw->clear();
	}
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple w;

	w.resize(400,200);

	w.setWindowTitle("QLISTEDIT WIDGETS");

	w.show();

	return app.exec();
}
