#include<QApplication>
#include<QWidget>
#include<QLabel>
#include<QVBoxLayout>
#include<QFont>



class simple : public QWidget
{
	public:
		simple(QWidget *parent = nullptr);
	private:
		QLabel *p1;
};
simple::simple(QWidget *parent)
	:QWidget(parent)
{
	QString data = "my name is arjun kumar\nI have done my schooling in mari gold public school\n";

	p1 = new QLabel(data,this);
	p1->setFont(QFont("Purisa",30));

	auto *v = new QVBoxLayout();	
	v->addWidget(p1);

	setLayout(v);
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple window;

	window.resize(400,200);

	window.setWindowTitle("QLabel");

	window.show();

	return app.exec();
}

