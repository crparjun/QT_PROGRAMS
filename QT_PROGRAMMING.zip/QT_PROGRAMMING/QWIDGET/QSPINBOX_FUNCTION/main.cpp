#include<QApplication>
#include<QWidget>
#include<QLabel>
#include<QHBoxLayout>
#include<QSpinBox>

class simple : public QWidget
{
	public:
		simple(QWidget *parent = nullptr);
	private : 
		QSpinBox *spin;
		QLabel *l1;
		QHBoxLayout *hor;
};
simple::simple(QWidget *parent)
	:QWidget(parent)
{
	hor = new QHBoxLayout(this);
	hor->setSpacing(15);

	spin = new QSpinBox(this);

	l1 = new QLabel("0",this);

	hor->addWidget(spin);
	hor->addWidget(l1);

	connect(spin,QOverload<int>::of(&QSpinBox::valueChanged),l1,QOverload<int>::of(&QLabel::setNum));

	setLayout(hor);
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple w;

	w.resize(400,400);
	w.setWindowTitle("QSpinBox Layout");

	w.show();

	return app.exec();
}
