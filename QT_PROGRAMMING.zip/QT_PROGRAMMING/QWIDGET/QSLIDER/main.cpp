#include<QApplication>
#include<QWidget>
#include<QSlider>
#include<QLabel>
#include<QHBoxLayout>

class simple : public QWidget
{
	public :
		simple(QWidget *parent = nullptr);
	
	private :

		QSlider *s1;
		QLabel *p1;
};

simple::simple(QWidget *parent)
	:QWidget(parent)
{
	auto *h = new QHBoxLayout(this);

	s1 = new QSlider(Qt::Horizontal,this);
	h->addWidget(s1);

	p1 = new QLabel("1",this);
	h->addWidget(p1);

	connect(s1,&QSlider::valueChanged,p1,QOverload<int>::of(&QLabel::setNum));

	setLayout(h);
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple window;

	window.resize(400,400);

	window.setWindowTitle("QT SLIDER");

	window.show();

	return app.exec();
}

