#include<QApplication>
#include<QWidget>
#include<QMainWindow>
#include<QFrame>
#include<QLabel>
#include<QPushButton>
#include<QStatusBar>
#include<QHBoxLayout>


class simple : public QMainWindow
{
	public:
		simple(QWidget *parent = nullptr);
		private slots:
			void ok();
		        void app();
	private:
			QPushButton *p1;
			QPushButton *p2;
};
simple::simple(QWidget *parent)
	:QMainWindow(parent)
{
	auto *frame = new QFrame(this);
	setCentralWidget(frame);



	auto *h1 = new QHBoxLayout(frame);

	p1 = new QPushButton("Ok",frame);
	h1->addWidget(p1,0,Qt::AlignLeft | Qt::AlignTop);
	
	p2 = new QPushButton("Apply",frame);	
	h1->addWidget(p2,1,Qt::AlignLeft | Qt::AlignTop);

	statusBar();
	

	connect(p1,&QPushButton::clicked,this,&simple::ok);
	connect(p2,&QPushButton::clicked,this,&simple::app);

}
void simple::ok()
{
	statusBar()->showMessage("ok button pressed",2000);
}
void simple::app()
{
	statusBar()->showMessage("Apply button pressed",2000);
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

		simple w;

	w.resize(400,400);

	w.setWindowTitle("QSATUSBAR FUNCTION");

	w.show();

	return app.exec();
}
