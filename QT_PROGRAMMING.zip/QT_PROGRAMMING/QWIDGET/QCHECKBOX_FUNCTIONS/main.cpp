#include<QApplication>
#include<QWidget>
#include<QLabel>
#include<QCheckBox>
#include<QHBoxLayout>

class simple : public QWidget
{
	public :
		simple(QWidget *parent = nullptr);
		private slots :
			void check( int );
};
simple::simple(QWidget *parent)
	:QWidget(parent)
{
	auto *h = new QHBoxLayout(this);

	auto *c = new QCheckBox("SHOW TITLE",this);
	c->setCheckState(Qt::Checked);
	h->addWidget(c,0,Qt::AlignLeft | Qt::AlignTop);


	connect(c,&QCheckBox::stateChanged,this,&simple::check);
}
void simple::check(int num)
{
	if(num == Qt::Checked)
	{
		setWindowTitle("QCheckBox");
	}
	else
	{
		setWindowTitle(" ");
	}
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple w;

	w.resize(400,200);

	w.setWindowTitle("QCHECKBOX-FUNCTION");

	w.show();

	return app.exec();
}
	
