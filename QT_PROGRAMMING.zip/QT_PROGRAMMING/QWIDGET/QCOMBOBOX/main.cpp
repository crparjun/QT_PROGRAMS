#include<QApplication>
#include<QWidget>
#include<QComboBox>
#include<QLabel>
#include<QHBoxLayout>
class simple : public QWidget
{
	public:
	simple(QWidget *parent = nullptr);
	private :
		QComboBox *c1;
		QLabel *l1;
};
simple::simple(QWidget *parent)
	:QWidget(parent)
{
	QStringList data = { "ORANGE", "MANGO" , "APPLES" , "GRAPHES" , "PAPAYA" , "BANANA" };

	auto *h = new QHBoxLayout(this);

	c1= new QComboBox(this);
	c1->addItems(data);

	h->addWidget(c1);
	h->addSpacing(15);


	l1 = new QLabel("Fruit categories",this);
	h->addWidget(l1);

	connect(c1,QOverload<const QString&>::of(&QComboBox::activated),l1,&QLabel::setText);

	setLayout(h);
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple w;

	w.resize(400,400);

	w.setWindowTitle("QCOMBOBOX FUNCTION");

	w.show();

	return app.exec();
}
