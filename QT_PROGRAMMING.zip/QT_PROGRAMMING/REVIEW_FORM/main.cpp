#include<QApplication>
#include<QWidget>
#include<QPushButton>
#include<QTextEdit>
#include<QLabel>
#include<QLineEdit>
#include<QGridLayout>
#include<QAction>

class simple : public QWidget
{
	public :
		simple(QWidget *parent = nullptr);
};
simple::simple(QWidget *parent)
	:QWidget(parent)
{
	auto *grid = new QGridLayout(this);
	grid->setVerticalSpacing(15);
	grid->setHorizontalSpacing(10);


	auto *p1 = new QLabel("Title:",this);
	grid->addWidget(p1,0,0,1,1);
	p1->setAlignment(Qt::AlignRight | Qt::AlignVCenter);

	auto *e1 = new QLineEdit(this);
	grid->addWidget(e1,0,1,1,1);

	auto *p2 = new QLabel("Author:",this);
	grid->addWidget(p2,1,0,1,1);
	p2->setAlignment(Qt::AlignRight | Qt::AlignVCenter); 


	auto *e2 = new QLineEdit(this);
	grid->addWidget(e2,1,1,1,1);

	auto *p3 = new QLabel("Review:",this);
	grid->addWidget(p3,2,0,1,1);
	p3->setAlignment(Qt::AlignRight | Qt::AlignVCenter);

	auto *e3 = new QLineEdit(this);
	e3->setGeometry(60,300,150,200);
	//grid->addWidget(e3,1,1,1,1);

	grid->addWidget(e3);

	//auto b1 = new QPushButton("Cancel",this);
	//b1->setGeometry(5,170,90,30);

//	connect(b1,&QAction::triggered,qApp,QApplication::accept);

	auto b2 = new QPushButton("Submit",this);
	b2->setGeometry(50,370,300,30);
	connect(b2,&QPushButton::clicked,qApp,&QApplication::quit);

	setLayout(grid);
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple window;

	window.resize(400,400);

	window.setWindowTitle("QT REVIEW PAGE");

	window.show();

	return app.exec();
}

