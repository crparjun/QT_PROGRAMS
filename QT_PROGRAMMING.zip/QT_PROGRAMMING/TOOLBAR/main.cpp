#include<QApplication>
#include<QWidget>
#include<QMainWindow>
#include<QToolBar>
#include<QAction>
#include<QPixmap>

class simple : public QMainWindow
{
	public:
		simple(QWidget *parent = nullptr);
};
simple::simple(QWidget *parent)
	:QMainWindow(parent)
{
	QPixmap newpix("page.jpg");
	QPixmap openmix("open.png");
        QPixmap quitpix("close.jpg");


	QToolBar *tool = addToolBar("main toolbar");
	
	tool->addAction(QIcon(newpix), "New File");
	tool->addAction(QIcon(openmix), "Open File");
	
	tool->addSeparator();
	
	QAction *quit = tool->addAction(QIcon(quitpix),"Quit Application");

	  connect(quit, &QAction::triggered, qApp, &QApplication::quit);
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);
	
	simple window;

	window.resize(400,200);

	window.setWindowTitle("TOOLBAR");

	window.show();

	return app.exec();
}


