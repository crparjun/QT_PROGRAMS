#include<QApplication>
#include<QWidget>
#include<QPushButton>

class push : public QWidget
{
	public :
		push(QWidget *parent = nullptr);
};
push::push(QWidget *parent)
	:QWidget(parent)
{
	auto *b1 = new QPushButton("BUTTON1",this);
	b1->setGeometry(100,100,100,30);
	b1->setStyleSheet("background-color:yellow;");

	connect(b1,&QPushButton::clicked,qApp,&QApplication::quit);
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	push window;

	window.resize(400,200);

	window.setStyleSheet("background-color:lightgrey;");

	window.setWindowTitle("QPUSHButton");

	window.show();

	return app.exec();
}
