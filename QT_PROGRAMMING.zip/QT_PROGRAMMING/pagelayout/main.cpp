#include <QApplication>
#include <QMainWindow>
#include <QPushButton>
#include <QLineEdit>
#include <QVBoxLayout>


int main(int argc, char *argv[])
{
	QApplication app(argc, argv);
	
	QMainWindow mainWindow;
	mainWindow.setGeometry(100, 100, 400, 200);

	QWidget centralWidget;
	mainWindow.setCentralWidget(&centralWidget);

	QVBoxLayout layout(&centralWidget);

	QPushButton fillFormButton("Fill Form", &centralWidget);
	layout.addWidget(&fillFormButton);

	QPushButton closeButton("Close", &centralWidget);
	layout.addWidget(&closeButton);

	QLineEdit employeeNameEdit(&centralWidget);
        employeeNameEdit.setPlaceholderText("Enter Employee Name");
	layout.addWidget(&employeeNameEdit);

	QPushButton submitButton("Submit", &centralWidget);
	layout.addWidget(&submitButton);
	submitButton.hide(); 

	 QObject::connect(&fillFormButton, &QPushButton::clicked, [&]() {
	 fillFormButton.hide();
	 closeButton.hide();
	 employeeNameEdit.show();
	 submitButton.show();
	 });

	 QObject::connect(&submitButton, &QPushButton::clicked, [&]() {
	 fillFormButton.show();
	 closeButton.show();
	 employeeNameEdit.clear();
	 employeeNameEdit.hide();
	 submitButton.hide();
	 });

	 QObject::connect(&closeButton, &QPushButton::clicked, &app, &QApplication::quit);
	 mainWindow.show();
	 return app.exec();
}



