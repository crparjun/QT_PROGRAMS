#include<QApplication>
#include<QWidget>
#include<QVBoxLayout>
#include<QHBoxLayout>
#include<QPushButton>
#include<QListWidget>

class simple : public QWidget
{
	public:
		simple(QWidget *parent = nullptr);
};

simple::simple(QWidget *parent)
	:QWidget(parent)
{
	auto *v = new QVBoxLayout(this);
	auto *h = new QHBoxLayout(this);

	auto *lw = new QListWidget(this);

	lw->resize(100,100);

	lw->addItem("APPLES");
	lw->addItem("MANGO");
	lw->addItem("GRAPHES");
	lw->addItem("ORANGE");
	lw->addItem("PAPAYA");

	auto *p1 = new QPushButton("ADD",this);
	auto *p2 = new QPushButton("RENAME",this);
	auto *p3 = new QPushButton("REMOVE",this);
	auto *p4 = new QPushButton("UNDO",this);
	auto *p5 = new QPushButton("SELECT",this);

	v->setSpacing(4);
	v->addStretch(1);

	v->addWidget(p1);
	v->addWidget(p2);
	v->addWidget(p3);
	v->addWidget(p4);
	v->addWidget(p5);

	h->addWidget(lw);
	h->addSpacing(30);
	h->addLayout(v);

	setLayout(h);

}

int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple window;

        window.resize(400,250);

	window.setWindowTitle("QNESTING FUNCTION");

	window.show();

	return app.exec();

}

