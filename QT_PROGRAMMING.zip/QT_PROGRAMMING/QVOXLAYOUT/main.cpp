#include<QApplication>
#include<QWidget>
#include<QMainWindow>
#include<QPushButton>
#include<QVBoxLayout>



class simple : public QWidget
{
	public :
		simple(QWidget *parent = nullptr);
};
simple::simple(QWidget *parent)
	:QWidget(parent)
{
	auto *vbox = new QVBoxLayout(this);
	vbox->setSpacing(1);

	auto *p1 = new QPushButton("Setting",this);
	p1->setStyleSheet("background-color:grey;");
	p1->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);

	auto *p2 = new QPushButton("Accounts",this);
	p2->setStyleSheet("background-color:grey;"); 
	p2->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);

	auto *p3 = new QPushButton("Loans",this);
	p3->setStyleSheet("background-color:grey;"); 
	p3->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);

	auto *p4 = new QPushButton("Advice",this);
	p4->setStyleSheet("background-color:grey;"); 
	p4->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);

	auto *p5 = new QPushButton("Testing",this);  
	p5->setStyleSheet("background-color:grey;"); 
	p5->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);

	vbox->addWidget(p1);
	vbox->addWidget(p2);
	vbox->addWidget(p3);
	vbox->addWidget(p4);
	vbox->addWidget(p5);

	setLayout(vbox);
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple window;

	window.resize(400,200);

	window.setWindowTitle("QVBOX LAYOUT");

	window.show();

	return app.exec();

}
