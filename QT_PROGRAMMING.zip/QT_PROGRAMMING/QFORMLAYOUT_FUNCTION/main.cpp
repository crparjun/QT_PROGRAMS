#include<QApplication>
#include<QWidget>
#include<QLineEdit>
#include<QLabel>
#include<QFormLayout>

class simple : public QWidget
{
	public:
		simple(QWidget *parent = nullptr);
};

simple::simple(QWidget *parent)
	:QWidget(parent)
{
	auto *p1 = new QLineEdit(this);
	auto *p2 = new QLineEdit(this);
	auto *p3 = new QLineEdit(this);


	auto *form = new QFormLayout;
	form->setLabelAlignment(Qt::AlignRight | Qt::AlignVCenter);

	form->addRow("Name   : ",p1);
	form->addRow("Class  : ",p2);
	form->addRow("Rollno : ",p3);

	setLayout(form);

}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);
	
	simple window;

	window.resize(400,200);

	window.setWindowTitle("QFORMLAYOUT");

	window.show();
	
	return app.exec();

}
