#include<QApplication>
#include<QWidget>
#include<QMainWindow>
#include<QPushButton>
#include<QHBoxLayout>
#include<QVBoxLayout>

class simple : public QWidget
{
	public:
		simple(QWidget *parent = nullptr);
	private :
		QPushButton *p1;
		QPushButton *p2;
};
simple::simple(QWidget *parent)
	:QWidget(parent)
{
	auto *vbox = new QVBoxLayout(this);
	auto *hbox = new QHBoxLayout();

	p1 = new QPushButton("OK",this);
	p1->setStyleSheet("background-color:grey;");

	p2 = new QPushButton("APPLY",this);
	p2->setStyleSheet("background-color:grey;");


	hbox->addWidget(p1,1,Qt::AlignRight);
	hbox->addWidget(p2,0);

	vbox->addStretch(1);
	vbox->addLayout(hbox);

}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple window;
	window.resize(400,200);
	window.setWindowTitle("QHBOXLAYOUT");
	window.show();
	return app.exec();
}


