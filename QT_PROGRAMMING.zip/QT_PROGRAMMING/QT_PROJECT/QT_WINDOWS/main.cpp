#include<QApplication>
#include<QWidget>
#include<QMainWindow>

int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	QMainWindow window;

	window.setStyleSheet("background-image:url(/home/arjun/QT_PROGRAMMING/QT_PROJECT/QT_WINDOWS/window_image.jpg);");

	window.resize(1000,600);

	window.show();

	return app.exec();

}
