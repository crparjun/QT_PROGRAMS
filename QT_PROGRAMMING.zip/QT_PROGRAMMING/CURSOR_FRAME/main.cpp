#include<QApplication>
#include<QWidget>
#include<QFrame>
#include<QGridLayout>

class frame : public QWidget
{
	public:
		frame(QWidget *parent = nullptr);
};
frame::frame(QWidget *parent)
	:QWidget(parent)
{

	auto *frame1 = new QFrame(this);
	frame1->setFrameStyle(QFrame::Box);
	frame1->setCursor(Qt::WaitCursor);

	auto *grid = new QGridLayout(this);
	grid->addWidget(frame1,0,0);

	setLayout(grid);
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);
	
	frame window;

	window.resize(400,200);

	window.setWindowTitle("Cursor and Frame");

	window.show();

	return app.exec();

}

