#include<QApplication>
#include<QMainWindow>
#include<QMenu>
#include<QMenuBar>
#include<QAction>

class simple : public QWidget
{
	public :
		simple(QWidget *parent = nullptr);
	
	private :
		QMenuBar *menu;
};

simple::simple(QWidget *parent)
	:QWidget(parent)
{
	menu = new QMenuBar(this);

	auto *quit1 = new QAction("&QUIT",this);
	auto *quit11 = new QAction("&OPEN",this);
	auto *quit21 = new QAction("&CLOSE",this);
	auto *quit31 = new QAction("&SAVE",this);
	auto *quit41 = new QAction("&SAVE AS",this);

	auto *quit2 = new QAction("&TEXT",this);
	auto *quit3 = new QAction("&IMAGE",this);
	auto *quit4 = new QAction("&FONT",this);
	auto *quit5 = new QAction("&PAGE SIZE",this);
	auto *quit6 = new QAction("&ABOUT",this);

	QMenu *file1 = menu->addMenu("&FILE");
	QMenu *file2 = menu->addMenu("&HOME");
	QMenu *file3 = menu->addMenu("&EDIT");
	QMenu *file4 = menu->addMenu("&INSERT");
	QMenu *file5 = menu->addMenu("&PAGELAYOUT");
	QMenu *file6 = menu->addMenu("&HELP");

	file1->addAction(quit1);
	file1->addAction(quit11);
	file1->addAction(quit21);
	file1->addAction(quit31);
	file1->addAction(quit41);


	file2->addAction(quit2);
	file3->addAction(quit3);
	file4->addAction(quit4);
	file5->addAction(quit5);
	file6->addAction(quit6);

	connect(quit1,&QAction::triggered,qApp,QApplication::quit);
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple window;

	window.resize(400,200);

	window.setWindowTitle("SIMPLE MENU BAR");

	window.show();

	return app.exec();

}

