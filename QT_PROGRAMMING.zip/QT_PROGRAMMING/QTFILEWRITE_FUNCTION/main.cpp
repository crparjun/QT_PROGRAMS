#include<QApplication>
#include<QWidget>
#include<QLabel>
#include<QLineEdit>
#include<QFile>
#include<QTextStream>
#include<QPushButton>
class simple : public QWidget
{
	public : 
		simple(QWidget *parent = nullptr);
		public slots:
			void write();
	private:
		QLineEdit *l1;
		QLabel *p1;
};
simple::simple(QWidget *parent)
	:QWidget(parent)
{
	p1 = new QLabel("Name :",this);
	p1->setGeometry(20,40,50,30);

	l1 = new QLineEdit(this);
	l1->setStyleSheet("background-color:lightgrey;");
	l1->setGeometry(80,40,100,30);

	
	auto *z1 = new QPushButton("submit",this);
	z1->setGeometry(80,100,50,25);
	z1->setStyleSheet("background-color:black;color:white;"); 
	
	
	connect(z1,&QPushButton::clicked,&QApplication::quit);
	connect(z1,&QPushButton::clicked,[&] () {
			simple::write();
			});
}
void simple::write()
{	
       	QString name = l1->text();
	 QFile file("data.txt");
	 if(file.open(QIODevice::WriteOnly | QIODevice::Text)) 
	 {
		 QTextStream out(&file);  
		 out << "Student Name : " << name << "\n"; 
		 file.close();  
	 }
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);
	
	simple w;

	w.resize(200,200);

	w.setStyleSheet("background-color:lightBlue;");
	w.setWindowTitle("QT FILE WRITE FUNCTION");

	w.show();

	return app.exec();
}
