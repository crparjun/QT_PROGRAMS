#include<QApplication>
#include<QMainWindow>
#include<QWidget>
#include<QMenu>
#include<QMenuBar>
#include<QAction>
#include<QTextEdit>
#include<QStatusBar>
#include<QTextStream>
#include<QFile>
#include<QFileDialog>
#include<QToolBar>
#include<QKeySequence>

class simple : public QMainWindow
{
	public : 
		simple(QWidget *parent = nullptr);
	private slots:
		void savefile();

	private :
		QMenuBar *menu;
		QTextEdit *text;
};

simple::simple(QWidget *parent)
	:QMainWindow(parent)
{
	menu = new QMenuBar(this);
	setMenuBar(menu);

        QMenu *file = menu->addMenu("&File");
	auto *p1 = new QAction("New", this);
	//p1->setShortcut(tr("Ctrl+N"));
	p1->setShortcut(QKeySequence(Qt::CTRL + Qt::Key_N));

	auto *p2 = new QAction("New Window",this);
	auto *p3 = new QAction("Open",this);
	auto *p4 = new QAction("Save",this);
	connect(p4,&QAction::triggered,this,&simple::savefile);

	auto *p5 = new QAction("Save As..",this);
	auto *p6 = new QAction("Page Setup",this);
	auto *p7 = new QAction("Print",this); 
	auto *p8 = new QAction("Exit",this);
	connect(p8,&QAction::triggered,qApp,QApplication::quit);

	file->addAction(p1);
	file->addAction(p2);
	file->addAction(p3);
	file->addAction(p4);
	file->addAction(p5);
	file->addAction(p6);
	file->addAction(p7);
	file->addAction(p8);


	QMenu *edit = menu->addMenu("&Edit"); 
	auto *q1 = new QAction("Undo",this);
	auto *q2 = new QAction("Cut",this);
	auto *q3 = new QAction("Copy",this);
	auto *q4 = new QAction("Paste",this);
	auto *q5 = new QAction("Delete",this);
	auto *q6 = new QAction("Search with Bing...",this);
	auto *q7 = new QAction("Find...",this);
	auto *q8 = new QAction("Find Next",this);
	auto *q9 = new QAction("Find Previous",this);
	auto *q10 = new QAction("Replace",this);
	auto *q11 = new QAction("Go To...",this);
	auto *q12 = new QAction("Select All",this);
	auto *q13 = new QAction("Time/Date",this);
	edit->addAction(q1);
	edit->addAction(q2);
	edit->addAction(q3);
	edit->addAction(q4);
	edit->addAction(q5);
	edit->addAction(q6);
	edit->addAction(q7);
	edit->addAction(q8);
	edit->addAction(q9);
	edit->addAction(q10);
	edit->addAction(q11);
	edit->addAction(q12);
	edit->addAction(q13);


	QMenu *format = menu->addMenu("&Format");
	auto *r1 = new QAction("Word Wrap",this);
	auto *r2 = new QAction("Font...",this);
	format->addAction(r1);
	format->addAction(r2); 


        QMenu *view = menu->addMenu("&View");
	auto *s1 = new QAction("Zoom",this);
	auto *s2 = new QAction("Status Bar",this);
	view->addAction(s1);
	view->addAction(s2);

	QMenu *help = menu->addMenu("&Help"); 
	auto *t1 = new QAction("View Help",this);
	auto *t2 = new QAction("Send Feedback",this);
	auto *t3 = new QAction("About Notepad",this);
	help->addAction(t1);
	help->addAction(t2);
	help->addAction(t3);
       
	text = new QTextEdit(this);
	setCentralWidget(text);
	statusBar()->showMessage("Starting_QT_Notepad");

}
void simple::savefile()
{
	QString fileName = QFileDialog::getSaveFileName(this, "Save File", QString(), "Text Files (*.txt)");
	if (!fileName.isEmpty()
		    {
		       QFile file(fileName);
		       if (file.open(QIODevice::WriteOnly | QIODevice::Text))
			{
			QTextStream stream(&file);
			stream << text->toPlainText();
			file.close();
			statusBar()->showMessage("File saved successfully.");
	                }
		        else
			{
			statusBar()->showMessage("Error: Unable to save file.");
			}
		   }
}


int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple window;

	window.resize(800,500);

	window.setWindowTitle("QT NOTEPAD");

	window.show();

	return app.exec();

}

