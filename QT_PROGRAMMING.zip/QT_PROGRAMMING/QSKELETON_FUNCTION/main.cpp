#include<QApplication>
#include<QWidget>
#include<QMainWindow>
#include<QTextEdit>
#include<QMenu>
#include<QMenuBar>
#include<QStatusBar>
#include<QAction>
#include<QToolBar>
#include<QPixmap>
#include<QIcon>


class simple : public QMainWindow
{
	public :
		simple(QWidget *parent = nullptr);
	private :
		QMenuBar *menu;
};

simple::simple(QWidget *parent)
	:QMainWindow(parent)
{

	menu = new QMenuBar(this);

	QPixmap newpix("page.jpg");
	QPixmap openpix("open.png");
	QPixmap closepix("close.jpg");
	QPixmap editpix("edit.png");
	QPixmap insertpix("insert.png");
	QPixmap helppix("help.png");

	auto *quit = new QAction("&QUIT",this);

	QMenu *file = menu->addMenu("&FILE");
	file->addAction(quit);

	connect(quit,&QAction::triggered,qApp,QApplication::quit);

	QToolBar *tool = addToolBar("main Toolbar");
	tool->addAction(QIcon(newpix),"NEW FILE");
	tool->addAction(QIcon(openpix),"OPEN FILE");
	tool->addSeparator();

	QAction *quit2 = tool->addAction(QIcon(closepix),"CLOSE FILE");
        
	connect(quit2,&QAction::triggered,qApp,&QApplication::quit);

	tool->addAction(QIcon(editpix),"EDIT FILE");
	tool->addAction(QIcon(insertpix),"INSERT FILE");
	tool->addAction(QIcon(helppix),"HELP");

	auto *edit = new QTextEdit(this);
	setCentralWidget(edit);
	statusBar()->showMessage("READY");
}
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);

	simple window;

	window.resize(400,200);

	window.setWindowTitle("QSKELETON FUNCTION");

	window.show();

	return app.exec();
}
